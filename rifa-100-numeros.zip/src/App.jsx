import { useState } from "react";

export default function App() {
  const [selectedNumbers, setSelectedNumbers] = useState([]);
  const [reservedNumbers, setReservedNumbers] = useState([]);
  const [formVisible, setFormVisible] = useState(false);
  const [currentNumber, setCurrentNumber] = useState(null);
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");

  const handleClick = (number) => {
    if (reservedNumbers.includes(number)) return;
    setCurrentNumber(number);
    setFormVisible(true);
  };

  const handleReserve = () => {
    if (name && whatsapp) {
      setReservedNumbers([...reservedNumbers, currentNumber]);
      setSelectedNumbers([
        ...selectedNumbers,
        { number: currentNumber, name, whatsapp }
      ]);
      setFormVisible(false);
      setName("");
      setWhatsapp("");
      setCurrentNumber(null);
    }
  };

  return (
    <div className="container">
      <h1>🎟️ Rifa 100 Números</h1>
      <p><strong>Premio:</strong> $300.000</p>
      <p><strong>Valor por número:</strong> $3.000</p>
      <p><strong>Sortea:</strong> 02 de mayo de 2025 - Lotería Santander</p>

      <div className="grid">
        {Array.from({ length: 100 }, (_, i) => i + 1).map((num) => (
          <button
            key={num}
            onClick={() => handleClick(num)}
            style={{
              backgroundColor: reservedNumbers.includes(num) ? '#f87171' : '#bbf7d0',
              padding: '10px',
              width: '50px',
              height: '50px',
              margin: '4px'
            }}
            disabled={reservedNumbers.includes(num)}
          >
            {num}
          </button>
        ))}
      </div>

      {formVisible && (
        <div className="form">
          <h2>Reservar número #{currentNumber}</h2>
          <input
            type="text"
            placeholder="Tu nombre"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            type="text"
            placeholder="WhatsApp"
            value={whatsapp}
            onChange={(e) => setWhatsapp(e.target.value)}
          />
          <button onClick={handleReserve}>Confirmar reserva</button>
        </div>
      )}

      <div>
        <h3>📋 Números Reservados</h3>
        <ul>
          {selectedNumbers.map((entry, idx) => (
            <li key={idx}>
              <strong>#{entry.number}</strong> - {entry.name} ({entry.whatsapp})
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
